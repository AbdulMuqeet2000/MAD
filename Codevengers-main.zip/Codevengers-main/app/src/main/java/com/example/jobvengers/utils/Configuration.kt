package com.example.jobvengers.utils

object Configuration {

    const val Base_URL = "https://f71a-202-47-49-155.ngrok-free.app/Jobvengerapp/"

}